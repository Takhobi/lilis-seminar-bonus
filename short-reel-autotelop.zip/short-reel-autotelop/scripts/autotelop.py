#!/usr/bin/env python3
"""カット済み動画に字幕・表紙・音声処理を加えるローカルCLI。作成: 2026-10-27。"""
import argparse
import copy
import functools
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
from datetime import datetime

ROOT = Path(__file__).resolve().parent
FONT = '/System/Library/Fonts/ヒラギノ角ゴシック W6.ttc'
SUBS = {'りぃつけ': 'りゅうすけ', 'りつけ': 'りゅうすけ'}
PUNCT = re.compile(r'([、。，．！？!?])')


def command(args, cwd=None):
    """シェルを介さず実行。失敗時は末尾の診断を返す。"""
    result = subprocess.run([str(x) for x in args], cwd=cwd, capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(f'{args[0]} が失敗しました:\n{result.stderr[-6000:]}')
    return result.stdout


def probe(path):
    data = json.loads(command(['ffprobe', '-v', 'error', '-show_streams', '-show_format',
                               '-of', 'json', path]))
    video = next((s for s in data['streams'] if s['codec_type'] == 'video'), None)
    if video is None:
        raise ValueError('入力には映像ストリームが必要です')
    duration = float(video.get('duration', data['format'].get('duration', 0)))
    if not math.isfinite(duration) or duration <= 0:
        raise ValueError('入力の尺を取得できません')
    return data, duration


def read_json(path):
    with Path(path).open(encoding='utf-8') as f:
        return json.load(f)


def write_json(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def load_preset(value=None):
    path = Path(value or ROOT / 'presets/basic.json').expanduser()
    if not path.is_file() and str(value) in ('basic', 'band', 'pop'):
        path = ROOT / 'presets' / f'{value}.json'
    p = read_json(path)
    p['name'] = p.get('name', path.stem)
    p['font'] = str(Path(p.get('font', FONT)).expanduser())
    if not Path(p['font']).is_file():
        raise ValueError(f"フォントがありません: {p['font']}")
    for key in ('max_chars', 'max_lines', 'font_size'):
        if not isinstance(p[key], int) or p[key] <= 0:
            raise ValueError(f'プリセットの {key} は正の整数にしてください')
    if not 0 <= p['y_center'] <= 1:
        raise ValueError('y_center は0〜1にしてください')
    for key in ('text_color', 'accent', 'outline_color', 'box_color', 'title_color', 'title_box_color'):
        if not re.fullmatch(r'#[0-9a-fA-F]{6}', p[key]):
            raise ValueError(f'{key} は #RRGGBB 形式にしてください')
    if not isinstance(p.get('subs', {}), dict) or not all(isinstance(a, str) and a and isinstance(b, str)
                                                       for a, b in p.get('subs', {}).items()):
        raise ValueError('subs は空でない文字列キーと文字列値の辞書にしてください')
    if not isinstance(p.get('keywords', []), list) or not all(isinstance(k, str) and k for k in p.get('keywords', [])):
        raise ValueError('keywords は空でない文字列のリストにしてください')
    return p, path.resolve()


def collapse_inline(s):
    # premiere-autocut/ppro_autocut.py の考え方を独立実装。短い反復は温存。
    for size in range(4, len(s) // 2 + 1):
        if len(s) % size == 0 and s == s[:size] * (len(s) // size):
            return s[:size]
    for size in range(len(s) // 2, 3, -1):
        for i in range(len(s) - 2 * size + 1):
            if s[i:i + size] == s[i + size:i + 2 * size]:
                return s[:i + size] + s[i + 2 * size:]
    return s


def replace_tokens(tokens, subs):
    """単語をまたぐ置換も扱い、置換語に元の時刻と最小確率を保持する。"""
    tokens = copy.deepcopy(tokens)
    for before, after in subs.items():
        text = ''.join(t['text'] for t in tokens)
        matches = list(re.finditer(re.escape(before), text))
        for match in reversed(matches):
            # 後ろから処理するので、まだ処理していない前側の文字位置は変化しない。
            offsets, pos = [], 0
            for t in tokens:
                offsets.append((pos, pos + len(t['text'])))
                pos += len(t['text'])
            hits = [i for i, (a, b) in enumerate(offsets) if a < match.end() and b > match.start()]
            if not hits:
                continue
            i, j = hits[0], hits[-1]
            left = tokens[i]['text'][:match.start() - offsets[i][0]]
            right = tokens[j]['text'][match.end() - offsets[j][0]:]
            probs = [t['probability'] for t in tokens[i:j + 1] if t['probability'] is not None]
            merged = dict(tokens[i], text=left + after + right, end=tokens[j]['end'],
                          probability=min(probs) if probs else None)
            tokens[i:j + 1] = [merged] if merged['text'] else []
    return tokens


def same_run(a, b):
    """aとbが同じ語の続きらしいか（カタカナ・長音・英数字の連続）。"""
    def kind(c):
        if re.fullmatch(r'[ァ-ヴー・]', c):
            return 'kata'
        if re.fullmatch(r'[0-9A-Za-z０-９Ａ-Ｚａ-ｚ]', c):
            return 'alnum'
        return None
    return bool(a and b) and kind(a) is not None and kind(a) == kind(b)


def wrap_words(words, max_chars, max_lines):
    """単語境界だけで改行。収まらない場合はNone（長大な単語はQA対象）。"""
    strings = [t['text'] for t in words]
    target = min(max_chars, sum(map(len, strings)) / max(1, math.ceil(sum(map(len, strings)) / max_chars)))

    @functools.lru_cache(None)
    def solve(i, remaining):
        if i == len(strings):
            return 0, []
        if remaining == 0:
            return None
        best, line = None, ''
        for j in range(i, len(strings)):
            line += strings[j]
            if len(line) > max_chars:
                break
            rest = solve(j + 1, remaining - 1)
            if rest is not None:
                # 長さを均しつつ助詞等の後ろを優先する。
                cost = (len(line) - target) ** 2 + rest[0]
                if line.endswith(('は', 'が', 'を', 'に', 'で', 'へ', 'と', 'も', 'から', 'まで')):
                    cost -= 3
                # whisperは「スト」「レッチ」のように語を細切れで返すため、
                # カタカナ・英数字が続く位置（＝1語の途中）では改行しない。
                if j + 1 < len(strings) and same_run(line[-1], strings[j + 1][:1]):
                    cost += 1000
                candidate = cost, [line] + rest[1]
                if best is None or cost < best[0]:
                    best = candidate
        return best

    result = solve(0, max_lines)
    return '\n'.join(result[1]) if result else None


def make_segments(raw_words, duration, preset):
    chunks, current = [], []

    def flush():
        if current:
            chunks.append(list(current))
            current.clear()

    # 置換で0.35秒以上の間をまたいで語を結合しない。
    tokens, group = [], []
    for word in raw_words:
        if group and word['start'] - group[-1]['end'] >= 0.35 - 1e-7:
            tokens.extend(replace_tokens(group, dict(SUBS, **preset.get('subs', {}))))
            group = []
        group.append(word)
    tokens.extend(replace_tokens(group, dict(SUBS, **preset.get('subs', {}))))
    for token in tokens:
        if current and token['start'] - current[-1]['end'] >= 0.35 - 1e-7:
            flush()
        for part in PUNCT.split(token['text'].strip()):
            if not part:
                continue
            if PUNCT.fullmatch(part):
                if part in '！？!?':
                    if current:
                        current[-1]['text'] += part
                    elif chunks:
                        # 「！？」の2字目やWhisperの独立した記号も失わない。
                        chunks[-1][-1]['text'] += part
                flush()
                continue
            word = dict(token, text=part)
            if current and wrap_words(current + [word], preset['max_chars'], preset['max_lines']) is None:
                flush()
            current.append(word)
    flush()
    segments = []
    for chunk in chunks:
        text = wrap_words(chunk, preset['max_chars'], preset['max_lines']) or ''.join(t['text'] for t in chunk)
        text = collapse_inline(text)
        if not text:
            continue
        emph = next((k for k in preset.get('keywords', []) if k in text.replace('\n', '')), None)
        if emph is None:
            # 数字＋単位を一語として扱う。Whisperが「3」「分」と分けても強調できる。
            match = re.search(r'[0-9０-９]+(?:[.,．][0-9０-９]+)*(?:分|秒|時間|日|回|本|人|枚|円|%|％|倍|歳|ヶ月|か月)?', text.replace('\n', ''))
            emph = match.group() if match else None
        low = list(dict.fromkeys(t['text'] for t in chunk if t['probability'] is not None and t['probability'] < 0.5))
        row = {'id': len(segments) + 1, 'start': max(0, float(chunk[0]['start'])),
               'end': min(duration, float(chunk[-1]['end'])), 'text': text,
               'emphasis': [emph] if emph else [], 'low_confidence': low}
        # 同じ認識の残留重複は近接時だけまとめる。離れた正当な反復は残す。
        if segments and row['text'] == segments[-1]['text'] and row['start'] - segments[-1]['end'] < 0.25:
            segments[-1]['end'] = row['end']
            segments[-1]['low_confidence'] = list(dict.fromkeys(segments[-1]['low_confidence'] + low))
        elif row['start'] < duration:
            segments.append(row)
    # .6秒ずつ表示できない短尺でも、全行に正の表示尺を配分しQAへ残す。
    # 句読点・単語境界を守り、開始時刻は可能な範囲で原発話に近づける。
    span = min(.6, duration / len(segments)) if segments else .6
    previous = -span
    for i, row in enumerate(segments):
        row['start'] = max(previous + span, min(row['start'], duration - (len(segments) - i) * span))
        previous = row['start']
    for i, row in enumerate(segments):
        limit = segments[i + 1]['start'] if i + 1 < len(segments) else duration
        row['end'] = min(limit, max(row['end'], row['start'] + 0.6))
        if 0 <= limit - row['end'] < 0.25 and i + 1 < len(segments):
            row['end'] = limit
        row['id'] = i + 1
    return segments


def transcribe(source, duration, preset, preset_path, model, outdir):
    # モデルの暗黙ダウンロード・ネット接続を禁止（既存キャッシュのみ）。
    os.environ['HF_HUB_OFFLINE'] = '1'
    os.environ['HF_HUB_DISABLE_TELEMETRY'] = '1'
    from faster_whisper import WhisperModel
    try:
        engine = WhisperModel(model, device='cpu', compute_type='int8', local_files_only=True,
                              cpu_threads=4, num_workers=1)
    except Exception as exc:
        raise RuntimeError(f'ローカルのWhisperモデルを読み込めません: {model}。取得・インストールは行いません。{exc}') from exc
    recognized, _ = engine.transcribe(str(source), language='ja', word_timestamps=True,
                                      vad_filter=True, condition_on_previous_text=False,
                                      repetition_penalty=1.1)
    words = []
    for segment in recognized:
        if segment.words:
            words.extend({'start': w.start, 'end': w.end, 'text': w.word.strip(), 'probability': w.probability}
                         for w in segment.words if w.word.strip())
        elif segment.text.strip():
            words.append({'start': segment.start, 'end': segment.end, 'text': segment.text.strip(), 'probability': None})
    data = {'source': str(source), 'duration': duration, 'preset': preset['name'],
            'preset_path': str(preset_path), 'title': None,
            'segments': make_segments(words, duration, preset)}
    validate_telop(data, duration)
    write_json(outdir / 'telop.json', data)
    write_subtitles(data, preset, outdir)
    write_report(data, preset, outdir, duration, rendered=False)
    return data


def validate_telop(data, duration):
    if not isinstance(data, dict) or not isinstance(data.get('segments'), list):
        raise ValueError('telop.json の segments はリストにしてください')
    ids, previous = set(), -1
    for row in data['segments']:
        if not isinstance(row.get('id'), int) or row['id'] in ids:
            raise ValueError('各テロップの id は一意の整数にしてください')
        ids.add(row['id'])
        a, b = row.get('start'), row.get('end')
        if not all(isinstance(x, (int, float)) and math.isfinite(x) for x in (a, b)):
            raise ValueError(f"#{row['id']}: 時刻は有限の秒数にしてください")
        if not 0 <= a < b <= duration + 0.001 or a < previous:
            raise ValueError(f"#{row['id']}: 0 <= start < end <= 動画尺・開始時刻順にしてください")
        previous = a
        if not isinstance(row.get('text'), str) or not row['text'].strip():
            raise ValueError(f"#{row['id']}: text は空でない文字列にしてください")
        for key in ('emphasis', 'low_confidence'):
            if not isinstance(row.get(key, []), list) or not all(isinstance(t, str) for t in row.get(key, [])):
                raise ValueError(f"#{row['id']}: {key} は文字列のリストにしてください")
    if data.get('title') is not None and not isinstance(data['title'], str):
        raise ValueError('title は文字列またはnullにしてください')


def ass_color(value):
    r, g, b = value.lstrip('#')[0:2], value.lstrip('#')[2:4], value.lstrip('#')[4:6]
    return f'&H00{b}{g}{r}'


def ass_text(text):
    # ASS制御タグ・改行記法をユーザーテキストから注入させない。
    return text.replace('\\', '＼').replace('{', '｛').replace('}', '｝').replace('\r', '').replace('\n', r'\N')


def emphasized_ass(text, phrases, accent):
    flat, index = '', []
    for i, ch in enumerate(text):
        if ch != '\n':
            flat += ch
            index.append(i)
    ranges = []
    for phrase in phrases:
        if not phrase:
            continue
        for m in re.finditer(re.escape(phrase), flat):
            ranges.append((index[m.start()], index[m.end() - 1] + 1))
    out, active = [], False
    for i, ch in enumerate(text):
        colored = any(a <= i < b for a, b in ranges)
        if colored != active:
            out.append('{\\c' + ass_color(accent) + '&}' if colored else r'{\c}')
            active = colored
        out.append(ass_text(ch))
    if active:
        out.append(r'{\c}')
    return ''.join(out)


def timestamp(seconds, ass=False):
    units = 100 if ass else 1000
    value = round(seconds * units)
    hour, value = divmod(value, 3600 * units)
    minute, value = divmod(value, 60 * units)
    second, fraction = divmod(value, units)
    if ass:
        return f'{hour}:{minute:02}:{second:02}.{fraction:02}'
    return f'{hour:02}:{minute:02}:{second:02},{fraction:03}'


def layout_text(text, preset, size=None, center=None):
    from PIL import ImageFont
    size = size or preset['font_size']
    lines = text.split('\n')
    # 手動改行を保持しつつ、ピクセル幅と上下UI安全域に合わせ縮小。
    desired_y = (preset['y_center'] if center is None else center) * 1920
    while size >= 8:
        font = ImageFont.truetype(preset['font'], size)
        half_height = len(lines) * size * 1.25 / 2 + preset['box_padding']
        if max(font.getlength(line) for line in lines) <= 972 - 2 * preset['box_padding'] and half_height * 2 <= 1535 - 231:
            y = max(231 + half_height, min(1535 - half_height, desired_y))
            return size, round(y)
        size -= 1
    return 8, 883


def write_subtitles(data, preset, outdir):
    from PIL import ImageFont
    fontname = ImageFont.truetype(preset['font'], preset['font_size']).getname()[0]
    outline = preset['box_padding'] if preset['box'] else preset['outline']
    header = f'''[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Telop,{fontname},{preset['font_size']},{ass_color(preset['text_color'])},{ass_color(preset['accent'])},{ass_color(preset['box_color'] if preset['box'] else preset['outline_color'])},{ass_color(preset['box_color'])},-1,0,0,0,100,100,0,0,{3 if preset['box'] else 1},{outline},0,5,54,54,0,1
Style: Title,{fontname},{preset.get('title_size', 64)},{ass_color(preset['title_color'])},{ass_color(preset['title_color'])},{ass_color(preset['title_box_color'])},{ass_color(preset['title_box_color'])},-1,0,0,0,100,100,0,0,3,16,0,5,54,54,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
    ass, srt = [header], []
    for n, row in enumerate(data['segments'], 1):
        size, y = layout_text(row['text'], preset)
        tags = f'{{\\an5\\pos(540,{y})\\fs{size}}}'
        if preset['pop']:
            tags += r'{\fscx92\fscy92\t(0,100,\fscx100\fscy100)}'
        text = emphasized_ass(row['text'], row.get('emphasis', []), preset['accent'])
        ass.append(f"Dialogue: 1,{timestamp(row['start'], True)},{timestamp(row['end'], True)},Telop,,0,0,0,,{tags}{text}\n")
        srt.append(f"{n}\n{timestamp(row['start'])} --> {timestamp(row['end'])}\n{row['text']}\n\n")
    if data.get('title'):
        # 長い見出しも画面外に出さず、明示改行を優先。
        title = data['title']
        size, y = layout_text(title, preset, size=64, center=0.17)
        end = min(data['duration'], preset['title_seconds']) if preset['title_seconds'] > 0 else data['duration']
        ass.append(f'Dialogue: 2,0:00:00.00,{timestamp(end, True)},Title,,0,0,0,,{{\\an5\\pos(540,{y})\\fs{size}}}{ass_text(title)}\n')
    (outdir / 'telop.ass').write_text(''.join(ass), encoding='utf-8')
    (outdir / 'telop.srt').write_text(''.join(srt), encoding='utf-8')


def normalize_filter(fit):
    if fit == 'crop':
        return '[0:v]fps=30,scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,setsar=1[base]'
    return ('[0:v]fps=30,split=2[bg][fg];'
            '[bg]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,gblur=sigma=35[blur];'
            '[fg]scale=1080:1920:force_original_aspect_ratio=decrease[front];'
            '[blur][front]overlay=(W-w)/2:(H-h)/2,setsar=1[base]')


def make_cover(source, duration, preset, outdir, fit, text, at):
    from PIL import Image, ImageDraw, ImageFont
    if not math.isfinite(at) or not 0 <= at < duration:
        raise ValueError('--cover-time は0以上かつ動画尺未満の秒数にしてください')
    with tempfile.TemporaryDirectory(prefix='.cover-', dir=outdir) as temp:
        frame = Path(temp) / 'frame.png'
        # 字幕の焼込前の映像に表紙文字を置く。
        filt = normalize_filter(fit).replace('[base]', '[cover]')
        command(['ffmpeg', '-v', 'error', '-y', '-ss', at, '-i', source, '-filter_complex_threads', '2',
                 '-filter_complex', filt, '-map', '[cover]', '-frames:v', '1', '-threads', '2', frame])
        im = Image.open(frame).convert('RGB')
    if text:
        draw = ImageDraw.Draw(im)
        size = 100
        while True:
            font = ImageFont.truetype(preset['font'], size)
            lines = []
            for explicit in re.split(r'[\n 　]+', text.strip()):
                line = ''
                for ch in explicit:
                    if line and font.getlength(line + ch) > 880:
                        lines.append(line)
                        line = ''
                    line += ch
                lines.append(line)
            line_h = math.ceil(size * 1.4)
            if line_h * len(lines) + 60 <= 1380 or size <= 8:
                break
            size -= 2
        top = 960 - line_h * len(lines) / 2
        width = max(font.getlength(line) for line in lines)
        if preset['box']:
            draw.rounded_rectangle((540 - width / 2 - 30, top - 20, 540 + width / 2 + 30,
                                    top + line_h * len(lines) + 20), radius=24, fill=preset['box_color'])
        for i, line in enumerate(lines):
            draw.text((540, top + i * line_h), line, font=font, anchor='mt', fill=preset['text_color'],
                      stroke_width=0 if preset['box'] else preset['outline'], stroke_fill=preset['outline_color'])
    im.save(outdir / 'cover.png')


def qa_findings(data, preset):
    findings = []
    for row in data['segments']:
        prefix = f"#{row['id']} ({row['start']:.2f}–{row['end']:.2f}秒)"
        seconds = row['end'] - row['start']
        cps = len(re.sub(r'\s', '', row['text'])) / seconds
        if cps > 8:
            findings.append(f'{prefix}: 読速 {cps:.2f}文字/秒（8超）')
        if seconds < 0.6 - 1e-6:
            findings.append(f'{prefix}: 表示 {seconds:.3f}秒（0.6未満）')
        for i, line in enumerate(row['text'].split('\n'), 1):
            if len(line) > preset['max_chars']:
                findings.append(f"{prefix}: {i}行目 {len(line)}文字（上限{preset['max_chars']}）")
        if len(row['text'].split('\n')) > preset['max_lines']:
            findings.append(f"{prefix}: 行数が上限{preset['max_lines']}超")
        for word in row.get('low_confidence', []):
            findings.append(f'{prefix}: low_confidence「{word}」（Whisper確率0.5未満）')
    if not any(row['start'] <= 2 and row['end'] > 0 for row in data['segments']):
        findings.append('先頭2秒以内にテロップがありません（つかみを確認）')
    return findings


def write_report(data, preset, outdir, duration, rendered=False, metadata=None):
    findings = qa_findings(data, preset)
    lines = ['# short-autotelop QA', '', '目的：自動生成字幕の確認箇所と再編集手順を残す。',
             f"確認日時：{datetime.now().astimezone().isoformat(timespec='seconds')}",
             f"入力：`{data['source']}` / 入力尺：{duration:.4f}秒 / プリセット：{preset['name']}",
             f"テロップ：{len(data['segments'])}枚 / QA検出：{len(findings)}件", '', '## QA検出', '']
    lines.extend([f'- {x}' for x in findings] or ['- 指定項目の検出なし（内容の正しさを保証するものではありません）'])
    if rendered:
        v = next(s for s in metadata['streams'] if s['codec_type'] == 'video')
        a = next(s for s in metadata['streams'] if s['codec_type'] == 'audio')
        final_duration = float(v.get('duration', metadata['format']['duration']))
        lines += ['', '## 出力確認', '',
                  f"- 映像：{v['width']}x{v['height']} / {v['r_frame_rate']}fps / {v['codec_name']} / {v['pix_fmt']}",
                  f"- 音声：{a['codec_name']} / {a['sample_rate']}Hz",
                  f'- 出力尺：{final_duration:.4f}秒 / 入力との差：{final_duration - duration:+.4f}秒',
                  '- `check/frames.json` に確認画像のテロップIDと中間時刻を記録（最大12枚）。',
                  '- 音声は loudnorm I=-14 / TP=-1.5 / LRA=11。BGM指定時はループ・ダッキング・末尾1.5秒フェード。']
    else:
        lines += ['', '映像のレンダーは未完了です。既存のfinal.mp4がある場合は前回の出力の可能性があります。']
    lines += ['', '## 次にやること', '',
              '- 上記の番号と low_confidence を原音・check画像で確認し、`telop.json` の text / start / end / emphasis を修正してください。',
              '- `render` を同じプリセット・BGM・表紙等のオプションで再実行してください。再文字起こしは修正を上書きします。',
              '- 投稿前に全編を再生して誤認識・読みやすさ・音量を確認してください。',
              '- 発話が密な箇所や動画端で最短0.6秒を確保できない場合はQAに残します。必要ならテキストや時刻を手動調整してください。', '']
    (outdir / 'report.md').write_text('\n'.join(lines), encoding='utf-8')


def render(source, info, duration, data, preset, outdir, args):
    data = copy.deepcopy(data)
    validate_telop(data, duration)
    if args.title is not None:
        data['title'] = args.title
    data.update(source=str(source), duration=duration, preset=preset['name'])
    cover_at = duration * 0.3 if args.cover_time is None else args.cover_time
    if not math.isfinite(cover_at) or not 0 <= cover_at < duration:
        raise ValueError('--cover-time は0以上かつ動画尺未満の秒数にしてください')
    bgm = Path(args.bgm).expanduser().resolve() if args.bgm else None
    if bgm and not bgm.is_file():
        raise ValueError(f'BGMがありません: {bgm}')
    if source == outdir / 'final.mp4':
        raise ValueError('入力映像と出力final.mp4が同一です。別の出力先にしてください')
    write_json(outdir / 'telop.json', data)
    write_subtitles(data, preset, outdir)
    # 後続処理が失敗しても、前回のfinalと今回のJSONを検証済みと誤認させない。
    write_report(data, preset, outdir, duration, rendered=False)
    ff = ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-i', source]
    has_audio = any(s['codec_type'] == 'audio' for s in info['streams'])
    next_input = 1
    if not has_audio:
        ff += ['-f', 'lavfi', '-i', 'anullsrc=r=48000:cl=stereo']
        voice = '[1:a]'
        next_input += 1
    else:
        voice = '[0:a:0]'
    filt = normalize_filter(args.fit) + ';[base]ass=filename=telop.ass[v];'
    filt += f'{voice}aresample=48000,aformat=channel_layouts=stereo,apad,atrim=duration={duration}[voice];'
    if bgm:
        ff += ['-stream_loop', '-1', '-i', bgm]
        fade = max(0, duration - 1.5)
        filt += (f'[voice]asplit=2[spoken][side];'
                 f'[{next_input}:a]aresample=48000,aformat=channel_layouts=stereo,volume=0.1,'
                 f'atrim=duration={duration},afade=t=out:st={fade}:d={min(1.5, duration)}[music];'
                 '[music][side]sidechaincompress=threshold=0.02:ratio=8:attack=20:release=300[duck];'
                 '[spoken][duck]amix=inputs=2:normalize=0:duration=first[mix];'
                 f'[mix]apad=pad_dur=3,loudnorm=I=-14:TP=-1.5:LRA=11,atrim=duration={duration}[a]')
    else:
        # loudnormの計測窓より短い無音ではNaNが生じるため、計測用の余白を足してから尺を戻す。
        filt += f'[voice]apad=pad_dur=3,loudnorm=I=-14:TP=-1.5:LRA=11,atrim=duration={duration}[a]'
    # 一時出力で完成前のfinal.mp4を残さず、成功時だけ置換。
    with tempfile.TemporaryDirectory(prefix='.render-', dir=outdir) as temp:
        final = Path(temp) / 'final.mp4'
        ff += ['-filter_complex_threads', '2', '-filter_complex', filt, '-map', '[v]', '-map', '[a]',
               '-t', duration, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-threads', '4',
               '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-movflags', '+faststart', final]
        command(ff, cwd=outdir)
        final.replace(outdir / 'final.mp4')
    cover_text = args.cover_text if args.cover_text is not None else (data['segments'][0]['text'] if data['segments'] else '')
    make_cover(source, duration, preset, outdir, args.fit, cover_text, cover_at)
    check = outdir / 'check'
    check.mkdir(exist_ok=True)
    for old in check.glob('frame_*.png'):
        old.unlink()
    rows = data['segments']
    indices = list(range(len(rows))) if len(rows) <= 12 else sorted({round(i * (len(rows) - 1) / 11) for i in range(12)})
    manifest = []
    for i in indices:
        row = rows[i]
        at = (row['start'] + row['end']) / 2
        name = f"frame_{row['id']:03}.png"
        command(['ffmpeg', '-v', 'error', '-y', '-ss', at, '-i', outdir / 'final.mp4',
                 '-frames:v', '1', '-threads', '2', check / name])
        manifest.append({'id': row['id'], 'time': round(at, 4), 'file': name})
    write_json(check / 'frames.json', manifest)
    metadata, _ = probe(outdir / 'final.mp4')
    write_report(data, preset, outdir, duration, rendered=True, metadata=metadata)
    return data


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='mode', required=True)
    for mode in ('transcribe', 'render', 'run'):
        p = sub.add_parser(mode)
        p.add_argument('input', type=Path)
        p.add_argument('--preset', help='プリセットJSON（既定basic。renderはJSON内の指定を継承）')
        p.add_argument('--outdir', type=Path)
        if mode in ('transcribe', 'run'):
            p.add_argument('--model', default='small', help='キャッシュ済みWhisperモデル名またはローカルパス')
        if mode == 'render':
            p.add_argument('--telop', type=Path, required=True)
        if mode in ('render', 'run'):
            p.add_argument('--bgm')
            p.add_argument('--title')
            p.add_argument('--cover-text')
            p.add_argument('--cover-time', type=float)
            p.add_argument('--fit', choices=('blur', 'crop'), default='blur')
    args = parser.parse_args(argv)
    try:
        source = args.input.expanduser().resolve()
        if not source.is_file():
            raise ValueError(f'入力がありません: {source}')
        info, duration = probe(source)
        outdir = (args.outdir.expanduser() if args.outdir else source.parent / (source.stem + '_short')).resolve()
        outdir.mkdir(parents=True, exist_ok=True)
        data = read_json(args.telop.expanduser()) if args.mode == 'render' else None
        value = args.preset
        if value is None and data:
            stored = data.get('preset_path', '')
            value = stored if stored and Path(stored).is_file() else data.get('preset', 'basic')
        preset, preset_path = load_preset(value)
        if args.mode in ('transcribe', 'run'):
            print(f'文字起こし: {source.name} / {args.model}', flush=True)
            data = transcribe(source, duration, preset, preset_path, args.model, outdir)
        if args.mode in ('render', 'run'):
            print(f"レンダー: {preset['name']} / {len(data['segments'])}枚", flush=True)
            data['preset_path'] = str(preset_path)
            data = render(source, info, duration, data, preset, outdir, args)
        print(f"完了: {outdir} / QA {len(qa_findings(data, preset))}件", flush=True)
        return 0
    except (OSError, ValueError, KeyError, TypeError, RuntimeError, ImportError) as exc:
        print(f'エラー: {exc}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
