# short-reel-autotelop

lilis × AIM SNS勉強会 vol.3 参加特典（2026-11）。カット済みのショート動画に、テロップ・強調・タイトル・BGM・表紙をつけて仕上げる、Claude用のスキルです。

使い方はClaudeに任せてください。Claudeデスクトップアプリ（Codeタブ）にこのZIPを添付して「このスキルを入れて、準備して」と送るだけです。

- 対応：Mac（Windowsはフォントの設定が必要）
- 必要なもの：ffmpeg / Python3 / faster-whisper / Pillow（足りないものはClaudeが確認してから入れます）
- 動画・音声はすべてこのパソコンの中で処理されます（外部のサービスには送りません）
